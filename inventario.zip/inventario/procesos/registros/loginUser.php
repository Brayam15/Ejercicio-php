<?php
    require_once dirname(__DIR__).'/../clases/conexion_db.php';
    require_once dirname(__DIR__).'/../clases/usuarios.php';

    $dat = new Usuario();
    $datos = array(
    $_POST['usuario'],
    $_POST['password']);    
    $ref=false;
    echo $dat->loginUser($datos);
    
?>