<?php
    require_once "../../clases/conexion_db.php";
    require_once "../../clases/usuarios,php";

    $obj = new usuarios();
    $pass = sha1($_post['password']);
    if(isset($_POST['registro'])){
        if(strlen($_POST['name']) < 1 && strlen($_POST['email']) < 1){
            $nombre = trim($_POST['nombre']);
            $apellido = trim($_POST['apellido']);
            $email = trim($_post['email']);
            $password = trim($_POST['$pass']);
            $fecha = trim($_POST['$fecha']);
            $consulta = "INSERT into usuarios(nombre, apellido, email, password, $fecha)
            VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6])";
            $resultado = mysqli_query($conexionDB, $consulta);
        }
    }

    /*$pass = sha1($_post['password']);

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    /*$datos = array(
        INSERT into usuarios(, `nombre`, `apellido`, `email`, `password`, `fechaCaptura`) 
        VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6]);

    echo $obj->registroUser($datos);*/
?>