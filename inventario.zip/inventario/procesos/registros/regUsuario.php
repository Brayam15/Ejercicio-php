<?php
    /*require_once "../clases/conexion_db.php";
    require_once "../clases/usuarios,php";*/

    require_once dirname(__DIR__).'/../clases/conexion_db.php';
    require_once dirname(__DIR__).'/../clases/usuarios.php';

    $dat = new Usuario();


    $pass = sha1($_POST['password']);
    $datos = array(
        $nombre = $_POST['nombre'],
        $apellido = $_POST['apellido'],
        $usuario = $_POST['usuario'],
        $pass);
        

    echo $dat->registroUser($datos);

?>