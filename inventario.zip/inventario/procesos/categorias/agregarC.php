<?php
session_start();
    require_once "../../clases/conexion_db.php";
    require_once "../../clases/categorias.php";
    $fecha = date("Y-m-d");
    $categoria = $_POST['categoria'];
    $datos = array(
        $categoria,
        $fecha
    );
    $obj = new categorias();
    echo $categoria->agregarCategoria($datos);

?>