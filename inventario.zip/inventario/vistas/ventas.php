<!DOCTYPE html>
<head>
    <title>Inicio</title>
    <?php
    require_once "menu.php";
    ?>
    
    <body>
        <div class="container">
            <h1>Venta de productos</h1>
            <div class="row">
                <div class="col-sm-12">
                    <span class="btn btn-primary btn-sm" id="ventaProductosBtn">Vender Producto</span>
                    <span class="btn btn-primary btn-sm" id="ventasHechasBtn">Ventas hechas</span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div id="ventaProductos"></div>
                    <div id="ventasHechas"></div>
                </div>
            </div>
        </div>
    </body>
</head>
</html>
<script type = "text/javascript">
    $(document).ready(function() {
        $('#ventaProductosBtn').click(function(){
            ocultar();
            $('#ventaProductos').load('ventas/ventasProductos.php');
            $('#ventaProductos').show();
        });
        $('#ventasHechasBtn').click(function(){
            ocultar();
            $('#ventasHechas').load('ventas/ventasHechas.php');
            $('#ventasHechas').show();
        });
    });
        function ocultar(){
            $('#ventaProductos').hide();
            $('#ventasHechas').hide();

        }
</script>        