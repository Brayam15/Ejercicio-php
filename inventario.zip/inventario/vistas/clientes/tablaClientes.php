<table class="table table-hover table-condensed table-bordered" style="text-align:center;">
    <tr>
        <td>Nombre</td>
        <td>Apellido</td>
        <td>Dirección</td>
        <td>Email</td>
        <td>Teléfono</td>
        <td>Editar</td>
        <td>Eliminar</td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>
            <span class="btn btn-warning btn-sm">
                <span class="glyphicon glyphicon-pencil">  
                </span>
            </span>
        </td>
        <td>
            <span class="btn btn-danger btn-sm">
                <span class="glyphicon glyphicon-remove"></span>
            </span>
        </td>
    </tr>
</table>