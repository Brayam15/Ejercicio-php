<!DOCTYPE html>
<head>
    <title>Clientes</title>
    <?php
    require_once "menu.php";
    ?>
    <link rel="stylesheet" type = "text/css" href="../librerias/bootstrap/css/bootstrap.css">
    <script src="../librerias/jquery-3.2.1.min.js"></script>
    <script src="../js/funciones.js"></script>
</head>
    <body>
        <div class="container">
            <h1>Clientes</h1>
            <div class = "row">
                <div class="col-sm 4">
                    <form id="cliente">
                        <label>Nombre</label>
                        <input type="text" class="form-control input-sm" id="nombre" name="nombre">
                        <label>Apellido</label>
                        <input type="text" class="form-control input-sm" id="apellido" name="apellido">
                        <label>Dirección</label>
                        <input type="text" class="form-control input-sm" id="direccion" name="direccion">
                        <label>Email</label>
                        <input type="text" class="form-control input-sm" id="email" name="email">
                        <label>Telefono</label>
                        <input type="text" class="form-control input-sm" id="telefono" name="telefono">
                        <p></p>
                        <span class="btn btn-primary" id="agregarCliente">Agregar</span>
                        </form>
                </div>
                <div class="col-sm-8">
                    <div id="tablaClient"></div>
                </div>
            </div>
        </div>
    </body>

</html>
<script type = "text/javascript">
        $(document).ready(function(){
            $('#tablaClient').load("clientes/tablaClientes.php");
            $('#agregarCliente').click(function(){
                vacios = validarFormulario('#cliente');
                if (vacios>0){
                    window.alert("Debes llenar todos los campos");
                    return false;
                }
                datos =$('#cliente').serialize();
                $.ajax({
                    url: '../procesos/registros/regUsuario.php',
                    type: "POST", 
                    data: datos, 
                     
                    success:function(datos){
                        $('#tablaUsers').load("usuarios/tablaClientes.php");
                        if(datos){

                            window.alert("Agregado con exito");
                        }else{
                            alert("Fallo al agregar");
                        }

                    }
                })
            })
        })
    </script>