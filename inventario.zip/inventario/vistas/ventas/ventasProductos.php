<h4>Vender producto</h4>
<div class="row">
    <div class="col-sm-4">
        <form id="ventaProductos">
            <label>Seleccionar cliente</label>
            <select class="form-control input-sm" id="cliente" name="cliente">
                <option value="A">Seleccionar</option>
            </select>
            <label>Producto</label>
            <select class="form-control input-sm" id="producto" name="producto"">
                <option value="A">Seleccionar</option>
            </select>
            <label>Descripcion</label>
            <textarea id = "descripcion" name="descripcion" class = "form-control input-sm"></textarea>
            <label>Cantidad</label>
            <input type="text" class="form-control input-sm" id="cantidad" name="cantidad">
            <label>Precio</label>
            <input type="text" class="form-control input-sm" id="precio" name="precio">
            <p></p>
            <span class="btn btn-primary" id="agregarVenta">Agregar</span>
        </form>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $('#cliente').select2();
        $('#producto').select2();

    });
</script>