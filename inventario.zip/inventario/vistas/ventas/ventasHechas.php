<h4>Registro de ventas</h4>
<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <div class="table-responsive">
            <table class="table table-hover table-condensed table-bordered" style="text-align:center;">
                <tr>
                    <td>Fecha</td>
                    <td>Cliente</td>
                    <td>Encargado</td>
                    <td>Total</td>
                    <td>Recibo</td>
                    <td>Reporte</td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div>
    </div>

</div>