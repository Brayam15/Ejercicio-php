<!DOCTYPE html>
<head>
    <title>Inicio</title>
    <?php
    require_once "menu.php";
    ?>
</head>


</html>