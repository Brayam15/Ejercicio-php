<!DOCTYPE html>
<html>
    <head>
        <title>ventas</title>
        <?php
            require_once 'dependencias.php';
        ?>
    </head>
    <body>
        
    </body>
    

</html>