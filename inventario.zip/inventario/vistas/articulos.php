<!DOCTYPE html>
<head>
    <title>Articulos</title>
    <?php
    require_once "menu.php";
    ?>
    <link rel="stylesheet" type = "text/css" href="../librerias/bootstrap/css/bootstrap.css">
    <script src="../librerias/jquery-3.2.1.min.js"></script>
    <script src="../js/funciones.js"></script>
</head>
<body>
    <div class = "container">
        <h1>Articulos</h1>
        <div class = "row">
            <div class = "col-sm-4">
                <form id = "articulos" enctype = "multipart/form-data">
                    <label></label>
                    <select type="text" class="form-control input-sm" id="" name="">
                        <option>Seleccionar categoría</option>
                    </select>
                        <label>Nombre articulos</label>
                        <input type="text" class="form-control input-sm" id="nombreArt" name="nombreArt">
                        <label>Descripción</label>
                        <input type="text" class="form-control input-sm" id="descripciónArt" name="descripciónArt">
                        <label>Cantidad</label>
                        <input type="text" class="form-control input-sm" id="cantidadArt" name="cantidadArt">
                        <label>Precio</label>
                        <input type="text" class="form-control input-sm" id="precioArt" name="precioArt">
                        <label>Imagen</label>
                        <input type="file" id="imagenArt" name="imagenArt">
                        <p></p>
                        <span id = agregarArt class = "btn btn-primary">Agregar</span>

                </form>
            </div>
            <div class = "col-sm-8">
                    <div id = "tablaArt"></div>
            </div>
        </div>
    </div>
</body>
</html>
<script type="text/javascript">
    $(document).ready(function(){
        $('#tablaArt').load("articulos/tablaArticulos.php");
        $('#agregarArt').click(function(){
            vacios = validarFormulario('#articulos');
            if (vacios>0){
                        alert("Debes llenar todos los campos");
                        return false;
                    }
            datos=$('#articulos').serialize();
            $.ajax({
                type: 'POST', 
                data:datos, url: "../procesos/categorias/agregarA.php", 
                success: function(r){
                    if(r==1){
                        alert("Categoria agregada con exito");
                    }else{
                        alertify.error("No se pudo agregar categoria");
                    }
                }
            });
        });
    })
</script>