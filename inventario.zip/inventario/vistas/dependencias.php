<link rel="stylesheet"type="text/css" href="../librerias/alertify/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../librerias/alertify/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">

<script src="../librerias/jquery-3.2.1.min.js"></script>
<script src="../librerias/alertifyjs/alertify.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script  src="../librerias/select2/js/select2.js"></script>
<script type="../js/funciones.js"></script>
