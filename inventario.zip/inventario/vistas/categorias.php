
<!DOCTYPE html>
<head>
    <title>Categorias</title>
    <?php
    require_once "menu.php";
    ?>
    <link rel="stylesheet" type = "text/css" href="../librerias/bootstrap/css/bootstrap.css">
    <script src="../librerias/jquery-3.2.1.min.js"></script>
    <script src="../js/funciones.js"></script>
</head>
<body>
    <div class="container">
        <h1>Categorias</h1>
        <div class="row">
            <div class="col-sm-4">
                <form id="categorias">
                    <label>Categorias</label>
                    <input type="text" class="form-control input-sm" name="categoria" id="categoria">
                    <p></p>
                    <span class="btn btn-primary" id="agregarC">Agregar</span>
                </form>
            </div>
            <div class="col-sm-6">
                <div id="tablaC"></div>
            </div>
        </div>   
    <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="actualizaC" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Actualizar Categorias</h4>
      </div>
      <div class="modal-body">
            <input type="" hidden id="idCategoria"name="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Guardar</button>
      </div>
    </div>
  </div>
</div>
</body>


</html>
<script type="text/javascript">
    $(document).ready(function(){
        $('#tablaC').load("categorias/tablaCategorias.php");
        $('#agregarC').click(function(){
            vacios = validarFormulario('#categorias');
            if (vacios>0){
                        alert("Debes llenar todos los campos");
                        return false;
                    }
            datos=$('#categorias').serialize();
            $.ajax({
                type: 'POST', 
                data:datos, url: "../procesos/categorias/agregarC.php", 
                success: function(r){
                    if(r==1){
                        alert("Categoria agregada con exito");
                    }else{
                        alert("No se pudo agregar categoria");
                    }
                }
            });
        });
    })
</script>
<script type="text/javascript">
function agregarD(idCategoria){
    $('#idCategoria').val(idCategoria);
}
</script>