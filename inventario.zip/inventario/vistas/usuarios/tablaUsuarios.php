<?php
    require_once "../../clases/conexion_db.php";
    $c = new conexionDb();
    $conexion = $c->conexion();

    $sql = "SELECT `id_usuario`, `nombre`, `apellido`, `email`, `fechaCaptura` FROM `usuarios`";
    $result = mysqli_query($conexion, $sql);
?>
<table class="table table-hover table-condensed table-bordered" style="text-align:center;">
    <tr>
        <td>Id usuario</td>
        <td>Nombre</td>
        <td>Apellido</td>
        <td>Correo</td>
        <td>Fecha de registro</td>
        <td>Editar</td>
        <td>Eliminar</td>
    </tr>
    <?php
        while ($ver = mysqli_fetch_row($result)):
    ?>
    <tr>
        <td><?php echo $ver[0]; ?></td>
        <td><?php echo $ver[1]; ?></td>
        <td><?php echo $ver[2]; ?></td>
        <td><?php echo $ver[3]; ?></td>
        <td><?php echo $ver[4]; ?></td>
        <td>
            <span class="btn btn-warning btn-sm">
                <span class="glyphicon glyphicon-pencil">  
                </span>
            </span>
        </td>
        <td>
            <span class="btn btn-danger btn-sm">
                <span class="glyphicon glyphicon-remove"></span>
            </span>
        </td>
    </tr>
    <?php endwhile; ?>
</table>