<!DOCTYPE html>
<head>
    <title>Usuarios</title>
    <?php
    require_once "menu.php";
    ?>
    <link rel="stylesheet" type = "text/css" href="../librerias/bootstrap/css/bootstrap.css">
    <script src="../librerias/jquery-3.2.1.min.js"></script>
    <script src="../js/funciones.js"></script>
</head>
<body>
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
            <div class="panel panel primary">
                <div class="panel panel-heading">Registrar usuario</div>
                    <div class="panel panel-danger">
                        <form id="formulario">
                            <label>Nombre</label>
                            <input type="text" class="form-control input-sm" name="nombre" id="nombre">
                            <label>Apellido</label>
                            <input type = "text" name = "apellido" id="apellido"
                                class="form-control input-sm">
                            <label>Correo</label>
                            <input type = "text" name = "usuario" id="usuario"
                                class="form-control input-sm">
                            <label>Password</label>
                            <input type = "password" name = "password" id="password"
                                class="form-control input-sm">
                            <p></p>
                            <span class="btn btn-primary btn-sm" id="registrar">Crear</span>
                        </form>                
                    </div>
                    <div class="col-sm">
                        <div id="tablaUsers"></div>
                    </div>
        </div>
    </div>
</body>
</html>
<script type = "text/javascript">
        $(document).ready(function(){
            $('#tablaUsers').load("usuarios/tablaUsuarios.php");
            $('#registrar').click(function(){
                vacios = validarFormulario('#formulario');
                if (vacios>0){
                    window.alert("Debes llenar todos los campos");
                    return false;
                }
                datos =$('#formulario').serialize();
                $.ajax({
                    url: '../procesos/registros/regUsuario.php',
                    type: "POST", 
                    data: datos, 
                     
                    success:function(datos){
                        $('#tablaUsers').load("usuarios/tablaUsuarios.php");
                        if(datos){

                            window.alert("Agregado con exito");
                        }else{
                            alert("Fallo al agregar");
                        }

                    }
                })
            })
        })
    </script>