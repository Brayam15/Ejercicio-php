<?php
    class Categorias{
        public function agregarCategoria($datos){
            $c = new conexionDb();
            $conexion = $c->conexion();

            $sql = "INSERT INTO categorias('nombreCategoria', 'fechaCaptura')
            values ('$datos[2]', '$datos[3])";
            return mysqli_query($conexion,$sql);

        }
    } 
?>