<?php
class conexionDb{
    private $servidor = "localhost:3306";
    private $usuario = "root";
    private $password = "";
    private $nombreDB = "inventario";

    private $conn;

    public function conexion(){
        $conn = new mysqli($this->servidor, $this->usuario, $this->password, $this->nombreDB);
        return $conn;
    }

}
$obj = new conexionDb();
if($obj->conexion()){
    echo "conentado";
}