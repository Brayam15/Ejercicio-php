<?php
    class Usuario{
        public function registroUser($datos){
            $c = new conexionDb();
            $conexion = $c->conexion();
            $fecha = date("Y-m-d");
            $sql = "INSERT into usuarios (nombre, apellido, email, password, fechaCaptura)
            values ('$datos[0]', '$datos[1]', '$datos[2]', '$datos[3]', '$fecha')";
            echo $sql;
            return mysqli_query($conexion, $sql);
        }

        public function loginUser($datos){
            $c  = new conexionDb();
            $conexion = $c->conexion();
            $password = sha1($datos[1]);
            $sql = "SELECT * from where email = '$datos[0] and password = '$password'";
            $result = mysqli_query($conexion,$sql);
            if(mysqli_num_rows($result)>0){
                return 1;
            }else{
                return 0;
            }
        }
    }
?>