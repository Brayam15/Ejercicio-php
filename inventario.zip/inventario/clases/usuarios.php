<?php
    require_once "../../clases/conexion_db";
    class usuarios{
        public function registroUser($datos){
            $c = new conexionDb();
            $conexion = $c->conexion();
            $fecha = date("Y-m-d");

            $sql = "INSERT into usuarios (nombre, apellido, email, password, fechaCaptura);
            values ('$datos[0]', '$datos[1]', '$datos[2]', '$datos[3]', '$fecha')";
            
            return mysqli_query($conexion, $sql);
        }
    }
?>