<script type="text/javascript">
    $('#').click(function(){
        datos=$('#').serialize();
        $.ajax({
            type: 'POST', data:datos, url: "../procesos", success: function(r){

            }
        });
    });

    function validarFormulario(formulario){
        datos=$('#' + formulario).serialize();
        d = datos.split('&');
        vacios = 0;
        for(i=0;i<d.length;i++){
            controles = datos[i].split('=');
            if(controles[1]=="A"||controles[1]==""){
                vacios++;
            }
        }
    }
</script>