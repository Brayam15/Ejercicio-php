<!DOCTYPE html>
<html>
<title>Registro</title>
        <link rel="stylesheet" type = "text/css" href="librerias/bootstrap/css/bootstrap.css">
        <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
        <script src="js/funciones.js"></script>
    </head>
        <body>
            <br><br><br>
            <div class="row">
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                        <div class="panel panel primary">
                            <div class="panel panel-heading">Registrar usuario</div>
                            <div class="panel panel-danger">
                                <form id="formulario">
                                    <label>Nombre</label>
                                    <input type="text" class="form-control input-sm" name="nombre" id="nombre">
                                    <label>Apellido</label>
                                    <input type = "text" name = "apellido" id="apellido"
                                    class="form-control input-sm">
                                    <label>Usuario</label>
                                    <input type = "text" name = "usuario" id="usuario"
                                    class="form-control input-sm">
                                    <label>Password</label>
                                    <input type = "password" name = "password" id="password"
                                    class="form-control input-sm">
                                    <p></p>
                                    <span class="btn btn-primary btn-sm" id="registrar">Registrar</span>
                                    <a href="index.php" class="btn btn-danger btn-sm">Cancelar</a>

                                </form>
                                    
                            </div>
                        </div>
                    </div>
        </body>

    <script type = "text/javascript">
        $(document).ready(function(){
            $('#registrar').click(function(){
                vacios = validarFormulario('#formulario');

                if (vacios>0){
                    window.alert("Debes llenar todos los campos");
                    return false;
                }
                datos =$('#formulario').serialize();
                $.ajax({
                    url: 'procesos/registros/regUsuario.php',
                    type: "POST", 
                    data: datos, 
                     
                    success:function(datos){
                        if(datos){
                            window.alert("Agregado con exito");
                            window.location('index.php');
                        }else{
                            alert("Fallo al agregar");
                        }

                    }
                })
            })
        })
    </script>
</html>
        

