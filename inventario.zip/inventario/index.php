<!DOCTYPE html>
<html>
    <head>
    <title>Login de usuario</title>
        <link rel="stylesheet" type = "text/css" href="librerias/bootstrap/css/bootstrap.css">
        <script src="librerias/jquery-3.2.1.min.js"></script>
    </head>
    <body>
        <br><br><br>
        <div class="container">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <div class="panel panel primary">
                        <div class="panel panel-heading">Sistema de ventas</div>
                        <div class="panel panel-body">
                            <p>

                            </p>
                            <form id="frmLogin">
                                <label>Usuario</label>
                                <input type="text" class="form-control input-sm" name="usuario" id=usuario>
                                <label>Password</label>
                                <input type = "password" name = "password" id="password"
                                class="form-control input-sm">
                                <p></p>
                                <span class="btn btn-primary btn-sm">Entrar</span>
                                <a href="registro.php" class="btn btn-danger btn-sm">Registrar</a>

                            </form>
                                
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                </div>
            </div>
        </div>
    </body>
</html>