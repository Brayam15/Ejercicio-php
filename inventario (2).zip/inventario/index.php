<!DOCTYPE html>
<html>
    <head>
    <title>Login de usuario</title>
        <link rel="stylesheet" type = "text/css" href="librerias/bootstrap/css/bootstrap.css">
        <script src="librerias/jquery-3.2.1.min.js"></script>
        <script src="js/funciones.js"></script>
    </head>
    <body>
        <br><br><br>
        <div class="container">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <div class="panel panel primary">
                        <div class="panel panel-heading">Inventario</div>
                        <div class="panel panel-body">
                            <p>

                            </p>
                            <form id="login">
                                <label>Usuario</label>
                                <input type="text" class="form-control input-sm" name="usuario" id=usuario>
                                <label>Password</label>
                                <input type = "password" name = "password" id="password"
                                class="form-control input-sm">
                                <p></p>
                                <span class="btn btn-primary btn-sm" id="entrada">Entrar</span>
                                <a href="registro.php" class="btn btn-danger btn-sm">Registrar</a>

                            </form>
                                
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                </div>
            </div>
        </div>
    </body>
</html>

<script type="text/javascript">
        $(document).ready(function(){
            $('#entrada').click(function(){

                vacios = validarFormulario('#login');
                if (vacios > 0) {
                    alert("Debes llenar todos los campos");
                }

                datos=$('#login').serialize();
                $.ajax({
                type: 'POST', 
                data:datos,
                 url: "procesos/registros/loginUser.php", 
                 success: function(datos){
                    window.location = "vistas/inicio.php";
                        /*if(datos != null){
                            window.location = "vistas/inicio.php";    
                        }else{
                            alert("Algo anda mal");
                        }*/
                    }
                
        });
    });
        });
</script>